from django.apps import AppConfig


class BpgConfig(AppConfig):
    name = 'bpg'
